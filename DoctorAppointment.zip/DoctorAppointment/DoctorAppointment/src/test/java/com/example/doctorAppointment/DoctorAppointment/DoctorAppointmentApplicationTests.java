package com.example.doctorAppointment.DoctorAppointment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorAppointmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
