package com.example.doctorAppoinment.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.doctorAppointment.Model.Doctor;


public interface IDoctorRepo extends JpaRepository<Doctor, Long> {

}
