package com.example.doctorAppointment.Controller;

import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.doctorAppoinment.Service.Impl.DoctorServiceImpl;
import com.example.doctorAppointment.Model.Doctor;
import com.example.doctorAppointment.Service.IDoctorService;


public class DoctorController {

	@Autowired 
	private IDoctorService services;

	private static Logger logger = LogManager.getLogger(DoctorServiceImpl.class);
	
	@PostMapping("/doctor")
	public Doctor create(@RequestBody Doctor doctor)
	{
		logger.info(" TeacherServiceImpl create()", doctor);
		return services.create(doctor);
	}
	@GetMapping("/AllPatients")
	public List<Doctor> getAllPatient(){
		logger.info(" TeacherServiceImpl create()");
		return services.getAllDoctor();
		
	}
	@GetMapping("/Doctor/{doctorId}")
	public Optional<Doctor> getById(@PathVariable("doctorId") Long doctorId){
		return services.getById(doctorId);
		
	}
	@DeleteMapping("/delete/{doctorId}")
	public void deleteDoctor(@PathVariable("doctorId") Long doctorId) {
		logger.info(" TeacherServiceImpl deleteTeacher()", doctorId);
		services.deleteDoctor(doctorId);
	}
	
}
