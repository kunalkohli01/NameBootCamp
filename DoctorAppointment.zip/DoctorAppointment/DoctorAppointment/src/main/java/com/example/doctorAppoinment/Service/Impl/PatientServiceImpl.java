package com.example.doctorAppoinment.Service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.doctorAppoinment.Repository.IPatientRepo;
import com.example.doctorAppointment.Model.Patient;
import com.example.doctorAppointment.Service.IPatientService;


@Service
public class PatientServiceImpl implements IPatientService{

	@Autowired
	 private IPatientService service;
	@Autowired
	private IPatientRepo repo;
	
	@Override
	public Patient create(Patient patient) {
	
		return repo.save(patient);
	}

	@Override
	public List<Patient> getAllPatient() {
		return repo.findAll();
	}

	@Override
	public Optional<Patient> getById(Long patientId) {
		
		return repo.findById(patientId);
	}

	@Override
	public void deletePatient(Long patientId) {
		
		this.repo.deleteById(patientId);
		
	}

}
