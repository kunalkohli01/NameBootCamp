package com.example.doctorAppoinment.Service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.doctorAppoinment.Repository.IDoctorRepo;
import com.example.doctorAppointment.Model.Doctor;
import com.example.doctorAppointment.Service.IDoctorService;
@Service
public class DoctorServiceImpl implements IDoctorService{

	@Autowired
	 private IDoctorService service;
	@Autowired
	private IDoctorRepo repo;
	
	@Override
	public Doctor create(Doctor doctor) {
		return repo.save(doctor);
	}

	@Override
	public List<Doctor> getAllDoctor() {
		return repo.findAll();
	}

	@Override
	public Optional<Doctor> getById(Long doctorId) {
		// TODO Auto-generated method stub
		return repo.findById(doctorId);
	}

	@Override
	public void deleteDoctor(Long doctorId) {
		this.repo.deleteById(doctorId);
		
	}

}
