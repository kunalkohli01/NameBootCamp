package com.example.doctorAppointment.Service;

import java.util.List;
import java.util.Optional;

import com.example.doctorAppointment.Model.Patient;


public interface IPatientService {

	Patient create(Patient patient);

	List<Patient> getAllPatient();

	Optional<Patient> getById(Long patientId);

	void deletePatient(Long patientId);

}
