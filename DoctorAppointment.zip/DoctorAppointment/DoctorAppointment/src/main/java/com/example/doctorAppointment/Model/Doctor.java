package com.example.doctorAppointment.Model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

public class Doctor {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long doctorId;
	private String doctorName;
	private String specification;
	private String availabilityTime;
	private String availabilityfromTime;
	
	@OneToMany
	private List<Patient> patient = new ArrayList<>();
	
	public List<Patient> getPatient() {
		return patient;
	}
	
	public Doctor() {
	}

	public Doctor(long doctorId, String doctorName, String specification, String availabilityTime,
			String availabilityfromTime, List<Patient> patient) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.specification = specification;
		this.availabilityTime = availabilityTime;
		this.availabilityfromTime = availabilityfromTime;
		this.patient = patient;
	}
	public void setPatient(List<Patient> patient) {
		this.patient = patient;
	}
	public long getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(long doctorId) {
		this.doctorId = doctorId;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getSpecification() {
		return specification;
	}
	public void setSpecification(String specification) {
		this.specification = specification;
	}
	public String getAvailabilityTime() {
		return availabilityTime;
	}
	public void setAvailabilityTime(String availabilityTime) {
		this.availabilityTime = availabilityTime;
	}
	public String getAvailabilityfromTime() {
		return availabilityfromTime;
	}
	public void setAvailabilityfromTime(String availabilityfromTime) {
		this.availabilityfromTime = availabilityfromTime;
	}

	
	
}
