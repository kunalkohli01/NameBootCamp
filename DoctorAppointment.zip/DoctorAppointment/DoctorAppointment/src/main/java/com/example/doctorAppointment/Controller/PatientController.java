package com.example.doctorAppointment.Controller;

import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.doctorAppoinment.Service.Impl.PatientServiceImpl;
import com.example.doctorAppointment.Model.Patient;
import com.example.doctorAppointment.Service.IPatientService;

public class PatientController {

	@Autowired 
	private IPatientService services;

	private static Logger logger = LogManager.getLogger(PatientServiceImpl.class);
	
	@PostMapping("/patient")
	public Patient create(@RequestBody Patient patient)
	{
		logger.info(" TeacherServiceImpl create()", patient);
		return services.create(patient);
	}
	@GetMapping("/AllPatients")
	public List<Patient> getAllPatient(){
		logger.info(" TeacherServiceImpl create()");
		return services.getAllPatient();
		
	}
	@GetMapping("/Patient/{patientId}")
	public Optional<Patient> getById(@PathVariable("patientId") Long patientId){
		logger.info(" TeacherServiceImpl getById()", patientId);
		return services.getById(patientId);
		
	}
	@DeleteMapping("/delete/{patientId}")
	public void deletePatient(@PathVariable("patientId") Long patientId) {
		logger.info(" TeacherServiceImpl deleteTeacher()", patientId);
		services.deletePatient(patientId);
	}
}
