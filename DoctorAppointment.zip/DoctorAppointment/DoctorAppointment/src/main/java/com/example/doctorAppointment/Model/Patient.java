package com.example.doctorAppointment.Model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Patient {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long patientId;
	private String patientname;
	private String emailid;
	private long mobileNo;
	private String dob;
	private String appointmentDate;
	
	@ManyToMany
	private List<Doctor> doctor = new ArrayList<>();
	
	public long getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public List<Doctor> getDoctor() {
		return doctor;
	}
	public void setDoctor(List<Doctor> doctor) {
		this.doctor = doctor;
	}
	public String getPatientname() {
		return patientname;
	}
	public void setPatientname(String patientname) {
		this.patientname = patientname;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getDob() {
		return dob;
	}
	public Patient() {
	}
	public Patient(long patientId, String patientname, String emailid, long mobileNo, String dob, String appointmentDate,
			List<Doctor> doctor) {
		super();
		this.patientId = patientId;
		this.patientname = patientname;
		this.emailid = emailid;
		this.mobileNo = mobileNo;
		this.dob = dob;
		this.appointmentDate = appointmentDate;
		this.doctor = doctor;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

}
