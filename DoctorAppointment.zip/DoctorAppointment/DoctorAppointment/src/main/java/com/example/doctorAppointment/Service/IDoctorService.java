package com.example.doctorAppointment.Service;

import java.util.List;
import java.util.Optional;

import com.example.doctorAppointment.Model.Doctor;


public interface IDoctorService {

	Doctor create(Doctor doctor);

	List<Doctor> getAllDoctor();

	Optional<Doctor> getById(Long doctorId);

	void deleteDoctor(Long doctorId);

}
